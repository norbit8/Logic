# (c) This file is part of the course
# Mathematical Logic through Programming
# by Gonczarowski and Nisan.
# File name: test_ex0.py

"""Tests all Chapter 0 tasks."""

from prelim.prelim_test import test_half

def test_task1(debug=False):
    test_half(debug)

test_task1(True)
