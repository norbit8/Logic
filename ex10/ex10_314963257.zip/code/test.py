import itertools
x = [1, 2, 3]
print ([p for p in itertools.product(x, repeat=3)])